# BluBerry home assistant

 BluBerry is a home assistant which is written in python.

Currently the BluBerry code is still under development.

Any use of the BluBerry code must have credits crediting this repository.

To use the code you must have these 3 options ticked off

 - A raspberry pi capable of running simple code
 - A microphone
 - A speaker

 I also have the goal of doing the most minimalist github repository ever with only 2 files README.md and main.py

 open to any bugs/feature requests!
 If you can help with the search feature please do as wikipedia is pretty innacurate with auto request. Stopping auto request would mean being very specific. So any help would be appreciated.

 Yep thats about it!

